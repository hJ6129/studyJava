package _2048.South;

import java.awt.*;
import javax.swing.*;
import _2048.Center.Tile;

public class South extends JLabel{
	public South() {
		setSize(500,100);
		setBackground(new Color(225,153,204));
		setOpaque(true);
	}
}
