package _2048.Center;

import javax.swing.*;
import java.awt.*;

public class GameOver extends JFrame{
	public GameOver(){
		setSize(500,440);
		setBackground(new Color(0,0,0));
	}
}
