package homework;

public class unit{
	int hp;
	String name;
}