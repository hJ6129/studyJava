package homework;
import homework.unit;

public class monster extends unit{
	double MONspownTime;
	double MONattSpeed;
	int MONdemage;
	
	public void MONatt(){
		System.out.println("������ ����!");
	}
}
