package day0604;
import java.util.*;

public class PrecipitationEx {
	public static void main(String[] args) {
		Vector<Integer> v = new Vector<Integer>();
		Scanner scanner = new Scanner(System.in);
		
		while(true){
			System.out.print("������ �Է� (0 �Է½� ����)>> ");
			int s = scanner.nextInt();
			if(s == 0)
				break;
			v.add(s);
			int a = 0, ss = 0;
			for(int i=0; i<v.size(); i++){
				int n = v.get(i);
				ss += n;
				a = ss / v.size();
				System.out.print(n + " ");
			}
			System.out.println("\n���� ��� " + a);
		}
		scanner.close();
	}
}
